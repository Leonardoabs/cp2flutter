class Students {
  String? name;
  String? series;
  String? age;

  Students({this.name, this.series, this.age});

  Students.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    series = json['series'];
    age = json['age'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    data['series'] = series;
    data['age'] = age;
    return data;
  }
}
