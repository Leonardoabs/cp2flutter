import 'package:/database';
import 'package:petshop/domain/animal.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

import '../domain/students.dart';

class StudentsDatanase {
  static final StudentsDatanase instance = StudentsDatanase._init();
  static Database? _database;
  
  StudentsDatanase._init();
  
  Future<Database> get database async {
    if (_database != null) {
      return _database!;
    }
    _database = await initDataBase(nameDB);
    return _database!;
  }
  
  Future<Database> initDataBase(String name) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, name);
    return await openDatabase(path, version: 1, onCreate: _onCreateDB);
  }
  
  Future<void> _onCreateDB(Database db, int version) async {
    await db.execute(createTable);
  }

  Future<int> insert(Students students) async {
    final db = await instance.database;
    return await db.insert(tableName, students.toJson());
  }

  Future<List<Students>> readAll() async {
    final db = await instance.database;
    final result = await db.query(tableName);
    return result.map((studentsJson) => Students.fromJson(studentsJson)).toList();
  }


}