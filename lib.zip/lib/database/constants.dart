const nameDB = "myApp";

const tableName = 'students';

const createTable = '''
  CREATE TABLE students(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    series TEXT NOT NULL,
    age TEXT NOT NULL
  )
''';